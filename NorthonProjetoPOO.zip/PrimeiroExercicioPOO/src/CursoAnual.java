public class CursoAnual extends Conta{
	
	String nome, mes, ano;
	double matricula, n1,n2,n3,n4,oitenta,vinte,media;
	
	public CursoAnual(double n1, double n2, double n3, double n4) {
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
		this.n4 = n4;
		
	}
	@Override
	public double mmedia() {
		
		oitenta = (n2 + n4) / 2 * 0.8;
		vinte = (n1 + n3) / 2 * 0.2;
		media = (oitenta + vinte);
		return media; 
	}
	@Override
	public String conceito() {
		oitenta = (n2 + n4) / 2 * 0.8;
		vinte = (n1 + n3) / 2 * 0.2;
		media = (oitenta + vinte) ;		
		if(media > 7) {
			return "Aprovado";
		}else {
			return "Reprovado";
		}
	}
}