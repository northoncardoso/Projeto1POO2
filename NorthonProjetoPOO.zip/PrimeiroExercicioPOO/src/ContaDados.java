
public class ContaDados {
	
	public ContaDados() {
		
	}
	
	public double salario() {
		return 0;
	}
	public String dados() {
		return "";
	}
}
