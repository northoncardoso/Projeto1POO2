public class PessoaFisica extends ContaDados{ // '-'
	
	String nome, cpf;
	int codigo;

	public PessoaFisica(String nome, String cpf, int codigo) {
		this.nome= nome;
		this.cpf = cpf;
		this.codigo = codigo;
	}

}								
