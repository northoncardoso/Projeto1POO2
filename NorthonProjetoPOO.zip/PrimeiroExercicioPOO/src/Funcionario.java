public class Funcionario extends ContaDados{

	String codigo, nome, cpf, cnpj;
	double horasTrabalhadas, valorHorasTrabalhadas, totalVendido;
	
	public Funcionario(double horasTrabalhadas, double totalVendido) {
		this.horasTrabalhadas = horasTrabalhadas;
		this.totalVendido = totalVendido;
	}
	
	@Override
	public double salario() {
		valorHorasTrabalhadas = 19;
		double salario = (valorHorasTrabalhadas * horasTrabalhadas) + totalVendido;
		return salario;
	}
	@Override	
	public String dados() {
		return "Não mostramos dados de nossos funcionarios";
	}

	

}