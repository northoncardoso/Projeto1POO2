public class Conta {

	public Conta() {
		
	}
	public double mmedia() {
		return 0;
	}
	public String conceito() {
		return " ";
	}
	
}
