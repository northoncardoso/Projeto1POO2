import javax.swing.JOptionPane;
public class CursoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = Integer.parseInt(JOptionPane.showInputDialog("Escolha quantas médias de alunos deseja calcular"));
		Conta[] contas = new Conta[i];
		
		for(int k = 0; k < contas.length; k++) {
			int escolha = Integer.parseInt(JOptionPane.showInputDialog("Indique em quais cursos os repectivos alunos estão\n"
																	+ "0 - Cursos Anuais\n"
																	+ "1 - Cursos Semestrais\n" 
																	+ "2 - Cursos Curtos\n"
																	+ "3 - Cursos Longos"));
			switch(escolha) {
			case 0:
				
				contas[k] = new CursoAnual(Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da primeira prova?")),
										   Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da segunda prova?")),
										   Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da terceira prova?")),
										   Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da quarta prova?")));
				break;
			case 1:
				contas[k] = new CursoSemestrais(Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da primeira prova?")),
												Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da segunda prova?")),
												Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da terceira prova?")));
								
				break;
			case 2 :
				contas[k] = new CursoCurtos(Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da primeira prova?")),
												Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da segunda prova?")));
				break;
			case 3 :
				contas[k] = new CursosLongos(Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da primeira prova?")),
												Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da segunda prova?")),
												Integer.parseInt(JOptionPane.showInputDialog("Qual a nota da terceira prova?")));
				break;
				default:
			}
		}
		for(int k = 0; k< contas.length; k++) {
			JOptionPane.showMessageDialog(null, "Média: " + contas[k].mmedia() + " Conceito: " + contas[k].conceito());
		}
	}

}