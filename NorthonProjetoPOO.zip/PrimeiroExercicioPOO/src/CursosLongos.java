
public class CursosLongos extends Conta {
	
	String nome, mes, ano;
	double matricula, n1,n2,n3,oitenta,vinte,media;
	
	
	public CursosLongos(double n1, double n2, double n3) {
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
	}
	@Override
	public String conceito() {
		media = (n1 + n2 + n3) / 3;
		if(media >9.01) {
			return "A: Aprovado";
		}if(9 > media && media> 7.01) {
			return "B: Aprovado";
		}if(7 > media && media > 6.01) {
			return "C: Reprovado";
		}if(6 > media && media > 5.01) {
			return "D: Reprovado";
		}else {
			return "E: Reprovado";
		}
	}
	@Override
	public double mmedia() {
		media = (n1 + n2 + n3) / 3;
		return media;
	}

}