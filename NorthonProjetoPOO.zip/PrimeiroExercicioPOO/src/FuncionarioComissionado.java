public class FuncionarioComissionado extends ContaDados {
	
	String codigo, nome, cpf, cnpj;
	double horasTrabalhadas, valorHorasTrabalhadas, totalVendido, comissao;
	
	public FuncionarioComissionado(double horasTrabalhadas, double totalVendido) {
		this.horasTrabalhadas = horasTrabalhadas;
		this.totalVendido = totalVendido;
	}

	@Override
	public double salario() {
		if(totalVendido < 12) {
			comissao = 150;
		}
		valorHorasTrabalhadas = 19;
		double salario = (valorHorasTrabalhadas * horasTrabalhadas) + comissao;
		return salario;
	}

	@Override
	public String dados() {
		return "Não mostramos dados de nossos funcionarios";
	}
	

}
