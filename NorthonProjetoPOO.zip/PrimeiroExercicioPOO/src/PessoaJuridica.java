public class PessoaJuridica extends ContaDados {
	
	 String nome;
	double cpf, cnpj,codigo;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getCpf() {
		return cpf;
	}
	public void setCpf(double cpf) {
		this.cpf = cpf;
	}
	public double getCnpj() {
		return cnpj;
	}
	public void setCnpj(double cnpj) {
		this.cnpj = cnpj;
	}
	public double getCodigo() {
		return codigo;
	}
	public void setCodigo(double codigo) {
		this.codigo = codigo;
	}
	
	public PessoaJuridica() {
		
	}
	
	public String dados(String nome, double cpf, double cnpj,double codigo) {
		this.nome= nome;
		this.cpf = cpf;
		this. cnpj = cnpj;
		this.codigo = codigo;
		return "Nome "+ nome + " CPF: " + cpf +" CNPJ: " + cnpj + " Codigo: " + codigo;
		
	}
	@Override 
	public double salario() {
		return 0;
	}
		// Poderia fazer uma matriz para armazenamento de cadastros...
}
