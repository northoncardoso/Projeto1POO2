import java.util.Scanner;
import javax.swing.JOptionPane;
public class FunPesMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int k = 1;
		ContaDados[]  transisoes= new ContaDados[k];
		
		
			for(int j = 0; j < transisoes.length; j++) {
				int escolha = Integer.parseInt(JOptionPane.showInputDialog("Escolha uma opção? \n"
																	+ "1 - Salario de um Funcionario Comissado\n"
																	+ "2 - Salario de um Funcionario\n"
																	+ "3 - Cadastro de uma Pessoa Juridica"));
				switch(escolha) {
					case 1 :
						transisoes[j] = new FuncionarioComissionado(Integer.parseInt(JOptionPane.showInputDialog("Quantas horas o funcionario trabalhou?")),
																	Integer.parseInt(JOptionPane.showInputDialog("Quantos itens o funcionario vendeu??")));					
						break;
					case 2 :
						transisoes[j] = new Funcionario(Integer.parseInt(JOptionPane.showInputDialog("Quantas horas o funcionario trabalhou?")),
														Integer.parseInt(JOptionPane.showInputDialog("Quantos itens o funcionario vendeu??")));					
						break;
					case 3 :

						PessoaJuridica j1 = new PessoaJuridica();
						
						System.out.println("Qual seu nome?");
						j1.setNome(sc.next());
						
						System.out.println("Qual o número do seu CPF?");
						j1.setCpf(sc.nextDouble());
						
						System.out.println("Qual o número do seu CNPJ?");
						j1.setCnpj(sc.nextDouble());
						
						System.out.println("Qual o código da Pessoa Juridica?");
						j1.setCodigo(sc.nextDouble());
									
						break;
					default :
				}
			}		
		
		for( k = 0; k< transisoes.length; k++) {
			JOptionPane.showMessageDialog(null, "Salario: " + transisoes[k].salario() + " Dados: " + transisoes[k].dados());
		}
		sc.close();
	}
}
