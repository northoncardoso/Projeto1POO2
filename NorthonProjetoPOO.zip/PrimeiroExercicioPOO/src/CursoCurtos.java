public class CursoCurtos extends Conta{
	
	String nome, mes, ano;
	double matricula, n1,n2,media;
	
	public CursoCurtos(double n1, double n2) {
		this.n1 = n1;
		this.n2 = n2;
		
	}
	@Override
	public double mmedia() {
		media = (n1 + n2) / 2;
		return media;
	}
	
	@Override
	public String conceito() {
		media = (n1 + n2) / 2;	
		if(media > 5) {
			return "Aprovado";
		}else {
			return "Reprovado";
		}
	}
}