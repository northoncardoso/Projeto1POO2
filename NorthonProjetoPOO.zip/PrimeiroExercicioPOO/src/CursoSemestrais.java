public class CursoSemestrais extends Conta {
	
	String nome, mes, ano;
	double matricula, n1,n2,n3,metade,media;
	
	public CursoSemestrais(double n1, double n2, double n3) {
		this.n1 = n1;
		this.n2 = n2;
		this.n3 = n3;
	}
	
	@Override
	public double mmedia() {
		metade = (n1 + n2)/2;
		media = (metade + n3) / 2;
		return media;
	}
	
	@Override
	public String conceito() {
		metade = (n1 + n2)/2;
		media = (metade + n3) / 2;		
		if(media > 6) {
			return "Aprovado";
		}else {
			return "Reprovado";
		}
	}
}