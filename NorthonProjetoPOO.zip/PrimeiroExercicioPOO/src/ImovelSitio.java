
public class ImovelSitio extends Imovel {

	double codigo,area,preso;
	String rua, numero, bairro, municipio;
	
	public String localizacao(String rua, String numero, String bairro, String municipio) {
		this.rua = rua;
		this.numero = numero;
		this.bairro = bairro;
		this.municipio = municipio;
		return "Rua: " + rua + "Numero: " + numero + "Bairro: " + bairro + "Municipio: " + municipio;
	}
}
